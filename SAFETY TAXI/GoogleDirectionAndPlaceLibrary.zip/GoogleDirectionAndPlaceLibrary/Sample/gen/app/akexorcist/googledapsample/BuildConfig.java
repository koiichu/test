/** Automatically generated file. DO NOT MODIFY */
package app.akexorcist.googledapsample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}